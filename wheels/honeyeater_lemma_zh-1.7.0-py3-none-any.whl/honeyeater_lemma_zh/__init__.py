"""Honeyeater lemma model and lookup list (zh, 1.7.0)."""

from pathlib import Path

ROOT = Path(__file__).parent
PIPELINE = ROOT / "pipeline"
LOOKUP = ROOT / "lookup.json"
RELEASE = ROOT / "release.json"
