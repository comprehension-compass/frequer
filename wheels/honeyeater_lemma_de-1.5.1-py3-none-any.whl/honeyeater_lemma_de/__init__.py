"""Honeyeater lemma model and lookup list (de, 1.5.1)."""

from pathlib import Path

ROOT = Path(__file__).parent
PIPELINE = ROOT / "pipeline"
LOOKUP = ROOT / "lookup.json"
RELEASE = ROOT / "release.json"
